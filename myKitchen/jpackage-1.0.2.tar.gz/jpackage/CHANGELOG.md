jpackage Cookbook CHANGELOG
===========================
This file is used to list changes made in each version of the jpackage cookbook.


v1.0.2
------
### Bug
- **[COOK-3416](https://tickets.opscode.com/browse/COOK-3416)** - Fix installation on EL6

v1.0.0
------
- [COOK-2127] - Use `platform_family` to add OS support

v0.10.0
-------
- Initial released version.
